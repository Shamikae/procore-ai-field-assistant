# Special Missions (2–5 Day Engagements)
- Day 1: Discovery (observe, interview, document means & methods).
- Day 2: Build (templates + guided flows).
- Day 3: Field Pilot (coach onsite, remove friction).
- Day 4–5: Measure & Retrospective (KPI snapshot + SOPs).
