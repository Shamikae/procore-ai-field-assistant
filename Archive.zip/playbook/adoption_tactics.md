# Adoption Tactics
- Shadow crews 1 day → map real steps.
- Reduce clicks and fields; default the rest.
- Micro-learning: 60–90s clips embedded into the flow.
- Add in-app checklists that mirror how crews actually work.
- Reward usage: weekly highlight of best logs/inspections.
