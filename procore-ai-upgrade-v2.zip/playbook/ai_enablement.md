# AI Enablement
- Voice → structured logs/inspections.
- Auto-summarize RFIs + daily reports.
- Suggest SOPs based on context (project, role, prior entries).
- Predictive alerts for schedule, safety, cost variance.
