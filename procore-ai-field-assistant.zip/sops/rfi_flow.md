# Micro-SOP: RFI Flow

1) Say: “Create RFI about <issue> at <location>.”  
2) Add photos or plan references.  
3) Confirm due date & route to design team.

**Pro Tip:** Include a proposed solution to speed up approvals.
