# Micro-SOP: Daily Log in 3 Steps

1) Kickoff — “Daily log for <Project>.”  
2) Details — weather, labor by trade, equipment hours, notes.  
3) Review & submit — the assistant generates a Procore-ready summary.

**Pro Tip:** Mention delays in plain language (“2 hours rain delay”) — it will be structured for you.
