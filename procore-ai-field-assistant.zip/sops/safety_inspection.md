# Micro-SOP: Run a Safety Inspection in 3 Steps

1) Start — say: “Create safety inspection for <Project>.”  
2) Confirm basics — crew size, incidents, photos.  
3) Review & submit — assistant outputs JSON; upload to Procore.

**Pro Tip:** Add site photos as you go; the assistant will tag them automatically.
